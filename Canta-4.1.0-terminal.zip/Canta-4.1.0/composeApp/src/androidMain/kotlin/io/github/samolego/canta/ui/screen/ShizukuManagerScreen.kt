package io.github.samolego.canta.ui.screen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import io.github.samolego.canta.generated.resources.Res
import io.github.samolego.canta.generated.resources.back
import io.github.samolego.canta.generated.resources.shizuku_apps_empty
import io.github.samolego.canta.generated.resources.shizuku_apps_need_service
import io.github.samolego.canta.generated.resources.shizuku_manager_title
import io.github.samolego.canta.generated.resources.shizuku_selinux
import io.github.samolego.canta.generated.resources.shizuku_tab_apps
import io.github.samolego.canta.generated.resources.shizuku_tab_home
import io.github.samolego.canta.generated.resources.shizuku_terminal_note
import io.github.samolego.canta.ui.dialog.BuiltInShizukuControls
import io.github.samolego.canta.util.LogUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.jetbrains.compose.resources.stringResource
import rikka.shizuku.Shizuku
import rikka.shizuku.embedded.AuthorizedApps

private const val TAG = "ShizukuManagerScreen"

private class ShizukuApp(
    val label: String,
    val packageName: String,
    val uid: Int,
    val icon: ImageBitmap?,
    allowed: Boolean,
) {
    var allowed by mutableStateOf(allowed)
}

/** Canta's built-in "Shizuku app": status and start methods, and the apps allowed to use it. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShizukuManagerScreen(onNavigateBack: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("> " + stringResource(Res.string.shizuku_manager_title)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(Res.string.back))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                    navigationIconContentColor = MaterialTheme.colorScheme.primary,
                ),
            )
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(stringResource(Res.string.shizuku_tab_home)) })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(stringResource(Res.string.shizuku_tab_apps)) })
            }
            if (tab == 0) HomeTab() else AppsTab()
        }
    }
}

@Composable
private fun HomeTab() {
    var running by remember { mutableStateOf(Shizuku.pingBinder()) }
    LaunchedEffect(Unit) {
        while (true) {
            running = Shizuku.pingBinder()
            delay(1000)
        }
    }
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BuiltInShizukuControls()
        if (running) {
            val selinux = try { Shizuku.getSELinuxContext() } catch (e: Throwable) { null }
            if (selinux != null) {
                Text(
                    text = stringResource(Res.string.shizuku_selinux, selinux),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }
        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
        Text(
            text = stringResource(Res.string.shizuku_terminal_note),
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Text(
            text = "Shizuku (Apache-2.0) / Shizuku-API (MIT) - RikkaApps",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(16.dp),
        )
    }
}

@Composable
private fun AppsTab() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<ShizukuApp>?>(null) }
    var running by remember { mutableStateOf(Shizuku.pingBinder()) }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Shizuku.pingBinder()
            if (now != running || (now && apps == null)) {
                running = now
                apps = if (now) withContext(Dispatchers.IO) { loadApps(context) } else null
            }
            delay(1500)
        }
    }

    if (!running) {
        Text(
            stringResource(Res.string.shizuku_apps_need_service),
            modifier = Modifier.padding(16.dp),
            style = MaterialTheme.typography.bodyMedium,
        )
        return
    }
    val list = apps
    if (list.isNullOrEmpty()) {
        Text(stringResource(Res.string.shizuku_apps_empty), modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
        return
    }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(list, key = { it.packageName + it.uid }) { app ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (app.icon != null) {
                    Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(40.dp))
                } else {
                    Spacer(modifier = Modifier.size(40.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(app.label, style = MaterialTheme.typography.titleSmall)
                    Text(app.packageName, style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = app.allowed,
                    onCheckedChange = { allow ->
                        try {
                            if (allow) AuthorizedApps.grant(app.uid) else AuthorizedApps.revoke(app.uid)
                            app.allowed = allow
                        } catch (e: Throwable) {
                            LogUtils.e(TAG, "Updating permission failed", e)
                        }
                    },
                )
            }
        }
    }
}

private fun loadApps(context: Context): List<ShizukuApp> =
    try {
        val packageManager = context.packageManager
        AuthorizedApps.packages()
            .filter { it.packageName != context.packageName }
            .mapNotNull { info ->
                val appInfo = info.applicationInfo ?: return@mapNotNull null
                ShizukuApp(
                    label = appInfo.loadLabel(packageManager).toString(),
                    packageName = info.packageName,
                    uid = appInfo.uid,
                    icon = try { appInfo.loadIcon(packageManager).toImageBitmap() } catch (e: Throwable) { null },
                    allowed = try { AuthorizedApps.granted(appInfo.uid) } catch (e: Throwable) { false },
                )
            }
            .sortedBy { it.label.lowercase() }
    } catch (e: Throwable) {
        LogUtils.e(TAG, "Loading apps failed", e)
        emptyList()
    }

private fun Drawable.toImageBitmap(size: Int = 96): ImageBitmap {
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    setBounds(0, 0, size, size)
    draw(canvas)
    return bitmap.asImageBitmap()
}
