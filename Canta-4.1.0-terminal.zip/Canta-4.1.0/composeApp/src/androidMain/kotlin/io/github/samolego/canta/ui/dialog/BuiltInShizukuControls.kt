package io.github.samolego.canta.ui.dialog

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import io.github.samolego.canta.generated.resources.Res
import io.github.samolego.canta.generated.resources.builtin_copied
import io.github.samolego.canta.generated.resources.builtin_copy_adb
import io.github.samolego.canta.generated.resources.builtin_root_failed
import io.github.samolego.canta.generated.resources.builtin_running
import io.github.samolego.canta.generated.resources.builtin_not_running
import io.github.samolego.canta.generated.resources.builtin_start_root
import io.github.samolego.canta.generated.resources.builtin_start_wireless
import io.github.samolego.canta.generated.resources.builtin_stop
import io.github.samolego.canta.generated.resources.builtin_version
import io.github.samolego.canta.util.LogUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.compose.resources.stringResource
import rikka.shizuku.Shizuku
import rikka.shizuku.embedded.EmbeddedShizuku

private const val TAG = "BuiltInShizukuControls"

/** Settings controls for the built-in Shizuku: status, start (Wireless debugging / root), stop, computer command. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BuiltInShizukuControls() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(Shizuku.pingBinder()) }
    var showStart by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            running = Shizuku.pingBinder()
            delay(1000)
        }
    }

    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            text = stringResource(if (running) Res.string.builtin_running else Res.string.builtin_not_running),
            style = MaterialTheme.typography.titleMedium,
            color = if (running) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
        if (running) {
            val uid = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
            val version = try { Shizuku.getVersion() } catch (e: Throwable) { 0 }
            Text(
                text = stringResource(Res.string.builtin_version, version, if (uid == 0) "root" else "shell"),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(top = 8.dp),
        ) {
            if (running) {
                OutlinedButton(onClick = {
                    try {
                        Shizuku.exit()
                    } catch (e: Throwable) {
                        LogUtils.e(TAG, "Stopping failed", e)
                    }
                    running = false
                }) { Text(stringResource(Res.string.builtin_stop)) }
            } else {
                OutlinedButton(onClick = { showStart = true }) {
                    Text(stringResource(Res.string.builtin_start_wireless))
                }
                OutlinedButton(onClick = {
                    scope.launch {
                        val output = withContext(Dispatchers.IO) {
                            try {
                                EmbeddedShizuku.startWithRoot(context)
                            } catch (e: Throwable) {
                                LogUtils.e(TAG, "Root start failed", e)
                                "ERROR: $e"
                            }
                        }
                        var waited = 0
                        while (waited < 8000 && !Shizuku.pingBinder()) {
                            delay(500)
                            waited += 500
                        }
                        running = Shizuku.pingBinder()
                        message = if (running) null else output.trim().ifEmpty { "su: no output" }
                        if (!running) LogUtils.e(TAG, "Root start did not bring the server up: $output")
                    }
                }) { Text(stringResource(Res.string.builtin_start_root)) }
            }
            OutlinedButton(onClick = {
                val clipboard = context.getSystemService(ClipboardManager::class.java)
                clipboard?.setPrimaryClip(
                    ClipData.newPlainText("Canta Shizuku", "adb shell ${EmbeddedShizuku.starterCommand(context)}")
                )
                message = "OK"
            }) { Text(stringResource(Res.string.builtin_copy_adb)) }
        }
        message?.let { msg ->
            Text(
                text = if (msg == "OK") stringResource(Res.string.builtin_copied) else stringResource(Res.string.builtin_root_failed) + "\n" + msg,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }

    if (showStart) {
        BuiltInShizukuDialog(onClose = { showStart = false })
    }
}
