package rikka.shizuku.embedded

import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.lifecycle.Observer
import moe.shizuku.manager.adb.AdbClient
import moe.shizuku.manager.adb.AdbKey
import moe.shizuku.manager.adb.AdbMdns
import moe.shizuku.manager.adb.AdbPairingClient
import moe.shizuku.manager.adb.PreferenceAdbKeyStore
import java.io.File

/**
 * Starts the embedded Shizuku server from inside the app, over the phone's own
 * Wireless debugging (Android 11+). The server needs shell rights, which only
 * adbd can give, so a one-time pairing with the device's own adbd is required.
 */
object EmbeddedShizuku {

    private const val HOST = "127.0.0.1"

    /** Command that starts the server (run as the shell user). */
    fun starterCommand(context: Context): String {
        val starter = File(context.applicationInfo.nativeLibraryDir, "libshizuku.so")
        return "${starter.absolutePath} --apk=${context.applicationInfo.sourceDir}"
    }

    private fun adbKey(context: Context): AdbKey {
        val prefs = context.getSharedPreferences("canta_adb_key", Context.MODE_PRIVATE)
        return AdbKey(PreferenceAdbKeyStore(prefs), "canta")
    }

    /** Pairs with the device's adbd using the code from "Pair device with pairing code". Blocking. */
    @RequiresApi(Build.VERSION_CODES.R)
    fun pair(context: Context, port: Int, code: String): Boolean =
        AdbPairingClient(HOST, port, code, adbKey(context)).use { it.start() }

    /** Connects to adbd (already paired) and starts the server. Blocking. Returns the starter's output. */
    @RequiresApi(Build.VERSION_CODES.R)
    fun start(context: Context, port: Int): String {
        val output = StringBuilder()
        AdbClient(HOST, port, adbKey(context)).use { client ->
            client.connect()
            client.shellCommand(starterCommand(context)) { output.append(String(it)) }
        }
        return output.toString()
    }

    /** Starts the server with root (`su`), for rooted devices. Blocking. Returns the output. */
    fun startWithRoot(context: Context): String {
        val process = ProcessBuilder("su", "-c", starterCommand(context)).redirectErrorStream(true).start()
        process.waitFor(10, java.util.concurrent.TimeUnit.SECONDS)
        val stream = process.inputStream
        val bytes = ByteArray(stream.available().coerceAtLeast(0))
        stream.read(bytes)
        return String(bytes)
    }

    /** Whether Wireless debugging is switched on in Developer options. */
    fun isWirelessDebuggingOn(context: Context): Boolean =
        try {
            android.provider.Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) == 1
        } catch (e: Exception) {
            false
        }

    /** Finds the pairing and connect ports advertised by Wireless debugging. */
    @RequiresApi(Build.VERSION_CODES.R)
    class PortDiscovery(
        context: Context,
        onPairingPort: (Int) -> Unit,
        onConnectPort: (Int) -> Unit,
    ) {
        private val pairing = AdbMdns(context, AdbMdns.TLS_PAIRING, Observer { onPairingPort(it) })
        private val connect = AdbMdns(context, AdbMdns.TLS_CONNECT, Observer { onConnectPort(it) })

        fun start() {
            pairing.start()
            connect.start()
        }

        fun stop() {
            pairing.stop()
            connect.stop()
        }
    }
}
