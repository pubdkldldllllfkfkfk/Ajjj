package rikka.shizuku.embedded

import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.lifecycle.Observer
import moe.shizuku.manager.adb.AdbClient
import moe.shizuku.manager.adb.AdbKey
import moe.shizuku.manager.adb.AdbMdns
import moe.shizuku.manager.adb.AdbPairingClient
import moe.shizuku.manager.adb.PreferenceAdbKeyStore
import java.io.File

/**
 * Starts the embedded Shizuku server from inside the app, over the phone's own
 * Wireless debugging (Android 11+). The server needs shell rights, which only
 * adbd can give, so a one-time pairing with the device's own adbd is required.
 */
object EmbeddedShizuku {

    private const val HOST = "127.0.0.1"

    /** Command that starts the server (run as the shell user). */
    fun starterCommand(context: Context): String {
        val starter = File(context.applicationInfo.nativeLibraryDir, "libshizuku.so")
        return "${starter.absolutePath} --apk=${context.applicationInfo.sourceDir}"
    }

    private fun adbKey(context: Context): AdbKey {
        val prefs = context.getSharedPreferences("canta_adb_key", Context.MODE_PRIVATE)
        return AdbKey(PreferenceAdbKeyStore(prefs), "canta")
    }

    /** Pairs with the device's adbd using the code from "Pair device with pairing code". Blocking. */
    @RequiresApi(Build.VERSION_CODES.R)
    fun pair(context: Context, port: Int, code: String): Boolean =
        AdbPairingClient(HOST, port, code, adbKey(context)).use { it.start() }

    /** Connects to adbd (already paired) and starts the server. Blocking. */
    @RequiresApi(Build.VERSION_CODES.R)
    fun start(context: Context, port: Int) {
        AdbClient(HOST, port, adbKey(context)).use { client ->
            client.connect()
            client.shellCommand(starterCommand(context), null)
        }
    }

    /** Finds the pairing and connect ports advertised by Wireless debugging. */
    @RequiresApi(Build.VERSION_CODES.R)
    class PortDiscovery(
        context: Context,
        onPairingPort: (Int) -> Unit,
        onConnectPort: (Int) -> Unit,
    ) {
        private val pairing = AdbMdns(context, AdbMdns.TLS_PAIRING, Observer { onPairingPort(it) })
        private val connect = AdbMdns(context, AdbMdns.TLS_CONNECT, Observer { onConnectPort(it) })

        fun start() {
            pairing.start()
            connect.start()
        }

        fun stop() {
            pairing.stop()
            connect.stop()
        }
    }
}
