// Shizuku server, API and Wireless-debugging starter, embedded in Canta so a
// separate Shizuku app is not needed. Sources come from RikkaApps/Shizuku
// (Apache-2.0) and RikkaApps/Shizuku-API (MIT); see NOTICE-SHIZUKU.md.
plugins {
    alias(libs.plugins.android.library)
}

android {
    namespace = "rikka.shizuku.embedded"
    compileSdk = libs.versions.android.compileSdk.get().toInt()

    defaultConfig {
        minSdk = libs.versions.android.minSdk.get().toInt()
        consumerProguardFiles("consumer-rules.pro")
        externalNativeBuild {
            cmake {
                arguments += "-DANDROID_STL=none"
            }
        }
    }

    buildFeatures {
        aidl = true
        prefab = true
        buildConfig = false
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/jni/CMakeLists.txt")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    packaging {
        jniLibs {
            // libshizuku.so is run as an executable, so it must exist on disk.
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.annotation:annotation:1.9.1")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.lifecycle:lifecycle-livedata-core:2.9.0")
    implementation("com.google.code.gson:gson:2.13.1")
    api("dev.rikka.rikkax.parcelablelist:parcelablelist:2.0.1")

    implementation("dev.rikka.hidden:compat:4.4.0")
    compileOnly("dev.rikka.hidden:stub:4.4.0")
    implementation("dev.rikka.tools.refine:runtime:4.4.0")

    implementation("io.github.vvb2060.ndk:boringssl:20250114")
    implementation("org.lsposed.libcxx:libcxx:27.0.12077973")
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:6.1")
    implementation("org.bouncycastle:bcpkix-jdk15on:1.70")
}
