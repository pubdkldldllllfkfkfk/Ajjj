package io.github.samolego.canta.ui.dialog

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import io.github.samolego.canta.generated.resources.Res
import io.github.samolego.canta.generated.resources.success_uninstalled
import io.github.samolego.canta.generated.resources.uninstall_icon
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random
import org.jetbrains.compose.resources.imageResource
import org.jetbrains.compose.resources.pluralStringResource

private const val GRID = 8
private const val DURATION_MS = 2200
private const val BREAK_AT = 0.35f

private class Shard(
    val col: Int,
    val row: Int,
    val spinDegrees: Float,
    val driftX: Float,
    val driftY: Float,
)

/**
 * Shown after apps were uninstalled: the app icon pops up, then shatters into
 * green pieces that fly apart. Closes itself when the animation ends.
 */
@Composable
fun UninstallShatterDialog(count: Int, onFinished: () -> Unit) {
    val icon = imageResource(Res.drawable.uninstall_icon)
    val green = MaterialTheme.colorScheme.primary
    val progress = remember { Animatable(0f) }
    val shards = remember {
        val random = Random(7)
        List(GRID * GRID) { i ->
            Shard(
                col = i % GRID,
                row = i / GRID,
                spinDegrees = (random.nextFloat() - 0.5f) * 540f,
                driftX = (random.nextFloat() - 0.5f) * 0.5f,
                driftY = random.nextFloat() * 0.4f,
            )
        }
    }

    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMillis = DURATION_MS, easing = LinearEasing))
        onFinished()
    }

    Dialog(
        onDismissRequest = onFinished,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(modifier = Modifier.size(260.dp)) {
                drawShatter(icon, shards, progress.value, green)
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = pluralStringResource(Res.plurals.success_uninstalled, count, count),
                color = green,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private fun DrawScope.drawShatter(icon: ImageBitmap, shards: List<Shard>, p: Float, green: Color) {
    val side = size.minDimension
    val center = Offset(size.width / 2f, size.height / 2f)

    if (p < BREAK_AT) {
        // Pop in with a small shake right before breaking.
        val t = p / BREAK_AT
        val pop = 0.6f + 0.4f * (1f - (1f - t) * (1f - t))
        val shake = if (t > 0.7f) sin(t * 90f) * 3f else 0f
        withTransform({
            translate(shake, 0f)
            scale(pop, pop, center)
        }) {
            drawImage(icon, dstSize = IntSize(side.toInt(), side.toInt()))
        }
        return
    }

    val t = (p - BREAK_AT) / (1f - BREAK_AT)

    // Green flash expanding from the middle.
    drawCircle(
        color = green.copy(alpha = (1f - t) * 0.45f),
        radius = side * (0.2f + 0.7f * t),
        center = center,
    )

    val tile = side / GRID
    val srcW = icon.width / GRID
    val srcH = icon.height / GRID
    val tint = ColorFilter.tint(green.copy(alpha = min(1f, t * 3f)), BlendMode.SrcAtop)
    val tilePx = ceil(tile).toInt()

    shards.forEach { s ->
        val cx = (s.col + 0.5f) * tile
        val cy = (s.row + 0.5f) * tile
        val dx = (cx - center.x) * 1.8f * t + s.driftX * side * t
        val dy = (cy - center.y) * 1.8f * t + s.driftY * side * t + side * 0.9f * t * t
        val alpha = (1f - t * t).coerceIn(0f, 1f)
        rotate(degrees = s.spinDegrees * t, pivot = Offset(cx + dx, cy + dy)) {
            drawImage(
                image = icon,
                srcOffset = IntOffset(s.col * srcW, s.row * srcH),
                srcSize = IntSize(srcW, srcH),
                dstOffset = IntOffset((cx - tile / 2f + dx).roundToInt(), (cy - tile / 2f + dy).roundToInt()),
                dstSize = IntSize(tilePx, tilePx),
                alpha = alpha,
                colorFilter = tint,
            )
        }
    }
}
