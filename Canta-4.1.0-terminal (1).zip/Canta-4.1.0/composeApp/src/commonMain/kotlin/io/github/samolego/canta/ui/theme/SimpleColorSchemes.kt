package io.github.samolego.canta.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

private val Gray = Color(0xFF9AA39B)

/** Terminal look: black background, a neon [accent], monospace text. */
internal fun greenColorScheme(accent: Color): ColorScheme {
    fun tone(f: Float) = lerp(Color.Black, accent, f)
    val text = lerp(Color.White, accent, 0.08f)
    return darkColorScheme(
        primary = accent,
        onPrimary = Color.Black,
        primaryContainer = tone(0.22f),
        onPrimaryContainer = accent,
        secondary = accent,
        onSecondary = Color.Black,
        secondaryContainer = tone(0.22f),
        onSecondaryContainer = accent,
        tertiary = tone(0.7f),
        onTertiary = Color.Black,
        tertiaryContainer = tone(0.22f),
        onTertiaryContainer = accent,
        background = Color.Transparent,
        onBackground = text,
        surface = Color.Black,
        onSurface = text,
        surfaceVariant = tone(0.05f),
        onSurfaceVariant = Gray,
        surfaceTint = accent,
        outline = tone(0.62f),
        outlineVariant = tone(0.30f),
        surfaceContainerLowest = Color.Black,
        surfaceContainerLow = tone(0.025f),
        surfaceContainer = tone(0.05f),
        surfaceContainerHigh = tone(0.075f),
        surfaceContainerHighest = tone(0.10f),
    )
}

/** Same terminal look in black and white. */
internal val BlackColorScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF1C1C1C),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFD0D0D0),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF1C1C1C),
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFFBDBDBD),
    onTertiary = Color.Black,
    tertiaryContainer = Color(0xFF1C1C1C),
    onTertiaryContainer = Color.White,
    background = Color.Transparent,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF111111),
    onSurfaceVariant = Color(0xFF9E9E9E),
    surfaceTint = Color.White,
    outline = Color(0xFF8A8A8A),
    outlineVariant = Color(0xFF333333),
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF0A0A0A),
    surfaceContainer = Color(0xFF111111),
    surfaceContainerHigh = Color(0xFF181818),
    surfaceContainerHighest = Color(0xFF202020),
)
