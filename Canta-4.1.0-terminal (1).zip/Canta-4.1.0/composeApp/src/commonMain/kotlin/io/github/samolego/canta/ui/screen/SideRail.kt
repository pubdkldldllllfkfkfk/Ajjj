package io.github.samolego.canta.ui.screen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardDoubleArrowRight
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.github.samolego.canta.data.app.AppBadgeInfo
import io.github.samolego.canta.data.app.Filter
import io.github.samolego.canta.generated.resources.Res
import io.github.samolego.canta.generated.resources.rail_all
import io.github.samolego.canta.generated.resources.rail_android
import io.github.samolego.canta.generated.resources.rail_apps
import io.github.samolego.canta.generated.resources.rail_recommended
import io.github.samolego.canta.generated.resources.rail_system
import io.github.samolego.canta.generated.resources.shizuku_btn_normal
import io.github.samolego.canta.generated.resources.shizuku_btn_pressed
import io.github.samolego.canta.ui.viewmodel.AppListViewModel
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

private val androidFilter = Filter(
    name = "Android",
    shouldShow = { app -> app.packageName.startsWith("com.android.") || app.packageName.startsWith("android.") },
)

/**
 * A neon side bar with quick list filters (All, Apps, System, Android, Recommended) and the Shizuku button.
 * The arrow at the bottom switches between icons with names and icons only; the small tab hides the bar.
 */
@Composable
fun SideRail(
    appListViewModel: AppListViewModel,
    showShizuku: Boolean,
    onOpenShizuku: () -> Unit,
) {
    var expanded by remember { mutableStateOf(true) }
    var hidden by remember { mutableStateOf(false) }
    val railWidth by animateDpAsState(if (expanded) 80.dp else 54.dp, tween(250), label = "railWidth")
    val filter = appListViewModel.selectedFilter
    val onlySystem = appListViewModel.onlySystem
    val recommended = Filter.availableFilters.firstOrNull { it.badgeInfo == AppBadgeInfo.RECOMMENDED } ?: Filter.any

    fun select(system: Boolean, newFilter: Filter) {
        appListViewModel.onlySystem = system
        appListViewModel.selectedFilter = newFilter
    }

    Row(modifier = Modifier.fillMaxHeight(), verticalAlignment = Alignment.CenterVertically) {
        AnimatedVisibility(
            visible = !hidden,
            enter = expandHorizontally(tween(300)) + fadeIn(tween(300)),
            exit = shrinkHorizontally(tween(300)) + fadeOut(tween(200)),
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary),
                modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp).fillMaxHeight().width(railWidth),
            ) {
                Column(
                    modifier = Modifier.fillMaxHeight().padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceEvenly,
                ) {
                    RailItem(Icons.Default.Folder, stringResource(Res.string.rail_all), !onlySystem && filter == Filter.any, expanded) {
                        select(false, Filter.any)
                    }
                    RailItem(Icons.Default.Apps, stringResource(Res.string.rail_apps), filter == Filter.user, expanded) {
                        select(false, Filter.user)
                    }
                    RailItem(Icons.Default.Settings, stringResource(Res.string.rail_system), onlySystem && filter == Filter.any, expanded) {
                        select(true, Filter.any)
                    }
                    RailItem(Icons.Default.Android, stringResource(Res.string.rail_android), filter == androidFilter, expanded) {
                        select(true, androidFilter)
                    }
                    RailItem(Icons.Default.Star, stringResource(Res.string.rail_recommended), filter == recommended && filter != Filter.any, expanded) {
                        select(true, recommended)
                    }
                    if (showShizuku) {
                        val interaction = remember { MutableInteractionSource() }
                        val pressed by interaction.collectIsPressedAsState()
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .clickable(interactionSource = interaction, indication = null, onClick = onOpenShizuku)
                                .padding(vertical = 4.dp, horizontal = 4.dp),
                        ) {
                            Image(
                                painter = painterResource(
                                    if (pressed) Res.drawable.shizuku_btn_pressed else Res.drawable.shizuku_btn_normal
                                ),
                                contentDescription = "Shizuku",
                                modifier = Modifier.size(if (expanded) 44.dp else 38.dp).clip(RoundedCornerShape(10.dp)),
                            )
                            if (expanded) {
                                Text("Shizuku", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.KeyboardDoubleArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { expanded = !expanded }
                            .graphicsLayer { rotationZ = if (expanded) 180f else 0f },
                    )
                }
            }
        }
        // The little tab that hides or shows the bar.
        val tabShape = RoundedCornerShape(12.dp)
        Box(
            modifier = Modifier
                .padding(end = 2.dp)
                .width(18.dp)
                .height(56.dp)
                .clip(tabShape)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f))
                .border(1.dp, MaterialTheme.colorScheme.primary, tabShape)
                .clickable { hidden = !hidden },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Default.Pause, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun RailItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    expanded: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .fillMaxWidth()
            .clip(shape)
            .then(
                if (selected) {
                    Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .border(1.dp, MaterialTheme.colorScheme.primary, shape)
                } else {
                    Modifier
                }
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
    ) {
        Icon(
            icon,
            contentDescription = label,
            modifier = Modifier.size(26.dp),
            tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        )
        if (expanded) {
            Text(
                label,
                fontSize = 10.sp,
                maxLines = 1,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}
