package io.github.samolego.canta.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val TerminalShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(4.dp),
    large = RoundedCornerShape(6.dp),
    extraLarge = RoundedCornerShape(8.dp),
)

/**
 * Canta has exactly two looks, both terminal-style: green on black, or
 * white on black. No dynamic/Material You colors; [black] is picked in Settings.
 */
@Composable
fun CantaTheme(
    black: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (black) BlackColorScheme else GreenColorScheme,
        typography = Typography,
        shapes = TerminalShapes,
        content = content
    )
}
