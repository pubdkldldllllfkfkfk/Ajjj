package io.github.samolego.canta.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * A very slow "wave of light" behind the app: a soft glow that drifts around and
 * three translucent waves that roll gently (one full cycle takes over a minute).
 */
@Composable
fun LightWaveBackground(accent: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "lightWave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(durationMillis = 70_000, easing = LinearEasing), RepeatMode.Restart),
        label = "wavePhase",
    )
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(durationMillis = 110_000, easing = LinearEasing), RepeatMode.Restart),
        label = "glowDrift",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Soft glow that wanders slowly across the screen.
        val glowCenter = Offset(w * (0.5f + 0.35f * cos(drift)), h * (0.3f + 0.2f * sin(drift * 0.7f)))
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = 0.14f), Color.Transparent),
                center = glowCenter,
                radius = w * 0.75f,
            ),
            radius = w * 0.75f,
            center = glowCenter,
        )

        // Three rolling waves, each a little slower/faster and in another direction.
        val layers = listOf(
            Triple(0.62f, 0.050f, 1.0f),
            Triple(0.72f, 0.040f, -1.3f),
            Triple(0.82f, 0.035f, 0.8f),
        )
        layers.forEachIndexed { i, (base, amplitude, speed) ->
            val path = Path()
            val step = 14f
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w + step) {
                val t = x / w
                val y = h * base +
                    h * amplitude * sin(t * 2f * PI.toFloat() * (1.2f + i * 0.4f) + phase * speed) +
                    h * amplitude * 0.5f * sin(t * 5f + phase * speed * 0.6f)
                path.lineTo(x, y)
                x += step
            }
            path.lineTo(w, h)
            path.close()
            drawPath(
                path = path,
                brush = Brush.verticalGradient(
                    colors = listOf(accent.copy(alpha = 0.18f - i * 0.045f), Color.Transparent),
                    startY = h * base - h * amplitude,
                    endY = h,
                ),
            )
        }
    }
}
