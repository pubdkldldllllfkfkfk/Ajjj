package io.github.samolego.canta.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * A very slow "wave of light" behind the app: two soft glows that drift around and four
 * translucent waves that roll gently. [speed]: 0 very slow, 1 slow, 2 normal.
 * [intensity]: 0 soft, 1 normal, 2 strong. Blurred on Android 12+ for soft edges.
 */
@Composable
fun LightWaveBackground(
    accent: Color,
    modifier: Modifier = Modifier,
    speed: Int = 1,
    intensity: Int = 1,
) {
    val slowness = when (speed) {
        0 -> 1.6f
        2 -> 0.5f
        else -> 1f
    }
    val strength = when (intensity) {
        0 -> 0.6f
        2 -> 1.6f
        else -> 1f
    }
    val transition = rememberInfiniteTransition(label = "lightWave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween((70_000 * slowness).toInt(), easing = LinearEasing), RepeatMode.Restart),
        label = "wavePhase",
    )
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween((110_000 * slowness).toInt(), easing = LinearEasing), RepeatMode.Restart),
        label = "glowDrift",
    )

    Canvas(modifier = modifier.fillMaxSize().blur(14.dp)) {
        val w = size.width
        val h = size.height

        // Two soft glows wandering in different directions.
        val glowA = Offset(w * (0.5f + 0.35f * cos(drift)), h * (0.3f + 0.2f * sin(drift * 0.7f)))
        val glowB = Offset(w * (0.5f + 0.4f * sin(drift * 0.6f)), h * (0.7f + 0.15f * cos(drift * 0.9f)))
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = (0.16f * strength).coerceAtMost(0.4f)), Color.Transparent),
                center = glowA,
                radius = w * 0.8f,
            ),
            radius = w * 0.8f,
            center = glowA,
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = (0.10f * strength).coerceAtMost(0.3f)), Color.Transparent),
                center = glowB,
                radius = w * 0.6f,
            ),
            radius = w * 0.6f,
            center = glowB,
        )

        // Four rolling waves, each at its own pace and direction.
        val layers = listOf(
            Triple(0.55f, 0.045f, 0.9f),
            Triple(0.66f, 0.050f, -1.2f),
            Triple(0.77f, 0.040f, 1.0f),
            Triple(0.88f, 0.035f, -0.7f),
        )
        layers.forEachIndexed { i, (base, amplitude, waveSpeed) ->
            val path = Path()
            val step = 14f
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w + step) {
                val t = x / w
                val y = h * base +
                    h * amplitude * sin(t * 2f * PI.toFloat() * (1.2f + i * 0.4f) + phase * waveSpeed) +
                    h * amplitude * 0.5f * sin(t * 5f + phase * waveSpeed * 0.6f)
                path.lineTo(x, y)
                x += step
            }
            path.lineTo(w, h)
            path.close()
            drawPath(
                path = path,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        accent.copy(alpha = ((0.17f - i * 0.03f) * strength).coerceIn(0f, 0.45f)),
                        Color.Transparent,
                    ),
                    startY = h * base - h * amplitude,
                    endY = h,
                ),
            )
        }
    }
}
