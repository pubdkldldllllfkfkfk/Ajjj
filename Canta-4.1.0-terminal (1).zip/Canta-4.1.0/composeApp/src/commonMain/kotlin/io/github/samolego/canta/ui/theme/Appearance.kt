package io.github.samolego.canta.ui.theme

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlin.math.absoluteValue
import kotlinx.coroutines.delay

/** What the user chose in Settings, "Appearance". */
data class Appearance(
    val waveEnabled: Boolean = true,
    /** 0 = very slow, 1 = slow, 2 = normal. */
    val waveSpeed: Int = 1,
    /** 0 = soft, 1 = normal, 2 = strong. */
    val waveIntensity: Int = 1,
    val glassCards: Boolean = false,
    val itemAnimations: Boolean = false,
)

val LocalAppearance = staticCompositionLocalOf { Appearance() }

/** Accent colours of the green theme; the first one is the classic neon green. */
val ACCENT_COLORS = listOf(
    Color(0xFF2EEA4A),
    Color(0xFF22D3EE),
    Color(0xFFB388FF),
    Color(0xFFFFC107),
    Color(0xFFFF5C8A),
    Color(0xFF4D8DFF),
)

/** Fades and slides a row in once, each one a little later than the other (not when animations are off). */
@Composable
fun Modifier.appearOnce(key: Any, maxDelayMs: Int = 260): Modifier {
    if (!LocalAppearance.current.itemAnimations) return this
    var visible by remember(key) { mutableStateOf(false) }
    LaunchedEffect(key) {
        delay((key.hashCode().absoluteValue % maxDelayMs).toLong())
        visible = true
    }
    val progress by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(450, easing = FastOutSlowInEasing),
        label = "appear",
    )
    return this.graphicsLayer {
        alpha = progress
        translationY = (1f - progress) * 24.dp.toPx()
    }
}

/** A springy little shrink while the row is pressed. */
@Composable
fun Modifier.pressScale(interactionSource: MutableInteractionSource): Modifier {
    if (!LocalAppearance.current.itemAnimations) return this
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
