package io.github.samolego.canta.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.github.samolego.canta.generated.resources.Res
import io.github.samolego.canta.generated.resources.appearance_accent
import io.github.samolego.canta.generated.resources.appearance_glass
import io.github.samolego.canta.generated.resources.appearance_glass_summary
import io.github.samolego.canta.generated.resources.appearance_intensity
import io.github.samolego.canta.generated.resources.appearance_item_anim
import io.github.samolego.canta.generated.resources.appearance_item_anim_summary
import io.github.samolego.canta.generated.resources.appearance_speed
import io.github.samolego.canta.generated.resources.appearance_wave
import io.github.samolego.canta.generated.resources.appearance_wave_summary
import io.github.samolego.canta.generated.resources.level_normal
import io.github.samolego.canta.generated.resources.level_soft
import io.github.samolego.canta.generated.resources.level_strong
import io.github.samolego.canta.generated.resources.speed_normal
import io.github.samolego.canta.generated.resources.speed_slow
import io.github.samolego.canta.generated.resources.speed_very_slow
import io.github.samolego.canta.ui.component.SettingsItem
import io.github.samolego.canta.ui.component.SwitchSettingsItem
import io.github.samolego.canta.ui.theme.ACCENT_COLORS
import io.github.samolego.canta.ui.viewmodel.SettingsViewModel
import org.jetbrains.compose.resources.StringResource
import org.jetbrains.compose.resources.stringResource

/** Settings rows for the look of the app: accent colour, animated background, glass cards, animations. */
@Composable
fun AppearanceSettingsItems(viewModel: SettingsViewModel, themeBlack: Boolean) {
    val waveEnabled by viewModel.waveEnabled.collectAsStateWithLifecycle()
    val waveSpeed by viewModel.waveSpeed.collectAsStateWithLifecycle()
    val waveIntensity by viewModel.waveIntensity.collectAsStateWithLifecycle()
    val accentIndex by viewModel.accentIndex.collectAsStateWithLifecycle()
    val glassCards by viewModel.glassCards.collectAsStateWithLifecycle()
    val itemAnimations by viewModel.itemAnimations.collectAsStateWithLifecycle()

    // Accent colour (the green theme only; the black theme is white).
    Column {
        SettingsItem(
            title = stringResource(Res.string.appearance_accent),
            icon = Icons.Default.ColorLens,
            enabled = !themeBlack,
        )
        Row(
            modifier = Modifier.padding(start = 56.dp, end = 16.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ACCENT_COLORS.forEachIndexed { index, color ->
                val selected = index == accentIndex
                Row(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(color)
                        .border(if (selected) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                        .clickable(enabled = !themeBlack) { viewModel.saveAccentIndex(index) },
                    content = {},
                )
            }
        }
    }

    SwitchSettingsItem(
        title = stringResource(Res.string.appearance_wave),
        description = stringResource(Res.string.appearance_wave_summary),
        icon = Icons.Default.Waves,
        checked = waveEnabled,
        onCheckedChange = viewModel::saveWaveEnabled,
    )
    if (waveEnabled) {
        ChipsItem(
            title = stringResource(Res.string.appearance_speed),
            icon = Icons.Default.Speed,
            selected = waveSpeed,
            labels = listOf(Res.string.speed_very_slow, Res.string.speed_slow, Res.string.speed_normal),
            onSelect = viewModel::saveWaveSpeed,
        )
        ChipsItem(
            title = stringResource(Res.string.appearance_intensity),
            icon = Icons.Default.Tune,
            selected = waveIntensity,
            labels = listOf(Res.string.level_soft, Res.string.level_normal, Res.string.level_strong),
            onSelect = viewModel::saveWaveIntensity,
        )
    }
    SwitchSettingsItem(
        title = stringResource(Res.string.appearance_glass),
        description = stringResource(Res.string.appearance_glass_summary),
        icon = Icons.Default.BlurOn,
        checked = glassCards,
        onCheckedChange = viewModel::saveGlassCards,
    )
    SwitchSettingsItem(
        title = stringResource(Res.string.appearance_item_anim),
        description = stringResource(Res.string.appearance_item_anim_summary),
        icon = Icons.Default.Animation,
        checked = itemAnimations,
        onCheckedChange = viewModel::saveItemAnimations,
    )
}

@Composable
private fun ChipsItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Int,
    labels: List<StringResource>,
    onSelect: (Int) -> Unit,
) {
    SettingsItem(
        title = title,
        icon = icon,
        trailing = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                labels.forEachIndexed { index, label ->
                    FilterChip(
                        selected = index == selected,
                        onClick = { onSelect(index) },
                        label = { Text(stringResource(label)) },
                    )
                }
            }
        },
    )
}
