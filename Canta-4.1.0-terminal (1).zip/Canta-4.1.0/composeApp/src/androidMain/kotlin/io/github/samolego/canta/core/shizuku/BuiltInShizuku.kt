package io.github.samolego.canta.core.shizuku

import android.content.Context

/** Canta always uses its own built-in Shizuku service (no separate Shizuku app needed). */
object BuiltInShizuku {
    @Suppress("UNUSED_PARAMETER")
    fun isEnabled(context: Context): Boolean = true

    @Suppress("UNUSED_PARAMETER")
    fun setEnabled(context: Context, enabled: Boolean) {
        // Kept for compatibility: the built-in service is always on.
    }
}
