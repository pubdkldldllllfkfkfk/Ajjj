package io.github.samolego.canta.ui.dialog

import android.Manifest
import android.app.Activity
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import io.github.samolego.canta.core.CantaHandler
import io.github.samolego.canta.core.shizuku.ShizukuPermission
import io.github.samolego.canta.generated.resources.Res
import io.github.samolego.canta.generated.resources.builtin_connect_port
import io.github.samolego.canta.generated.resources.builtin_need_notification
import io.github.samolego.canta.generated.resources.builtin_needs_android_11
import io.github.samolego.canta.generated.resources.builtin_notification_sent
import io.github.samolego.canta.generated.resources.builtin_pair_notification
import io.github.samolego.canta.generated.resources.builtin_open_dev_options
import io.github.samolego.canta.generated.resources.builtin_wireless_off
import io.github.samolego.canta.generated.resources.builtin_not_running
import io.github.samolego.canta.generated.resources.builtin_pair
import io.github.samolego.canta.generated.resources.builtin_pair_failed
import io.github.samolego.canta.generated.resources.builtin_paired
import io.github.samolego.canta.generated.resources.builtin_pairing_code
import io.github.samolego.canta.generated.resources.builtin_pairing_port
import io.github.samolego.canta.generated.resources.builtin_running
import io.github.samolego.canta.generated.resources.builtin_show_log
import io.github.samolego.canta.generated.resources.builtin_start
import io.github.samolego.canta.generated.resources.builtin_start_failed
import io.github.samolego.canta.generated.resources.builtin_starting
import io.github.samolego.canta.generated.resources.builtin_steps
import io.github.samolego.canta.generated.resources.builtin_title
import io.github.samolego.canta.generated.resources.close
import io.github.samolego.canta.ui.component.CantaDialog
import io.github.samolego.canta.util.LogUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.compose.resources.stringResource
import rikka.shizuku.Shizuku
import moe.shizuku.manager.adb.AdbPairingService
import rikka.shizuku.embedded.EmbeddedShizuku

private const val TAG = "BuiltInShizukuDialog"

private enum class Step { IDLE, PAIRED, PAIR_FAILED, STARTING, START_FAILED, NEEDS_NOTIFICATIONS, NOTIFICATION_SENT }

/**
 * Starts Canta's built-in Shizuku service. Needs Wireless debugging (Android 11+):
 * pair once with the code shown by the system, then start the service.
 */
@Composable
fun BuiltInShizukuDialog(
    onClose: (shouldProceed: Boolean) -> Unit,
    handler: CantaHandler? = null,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val supported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

    var pairingPort by remember { mutableStateOf("") }
    var pairingCode by remember { mutableStateOf("") }
    var connectPort by remember { mutableStateOf("") }
    var step by remember { mutableStateOf(Step.IDLE) }
    var log by remember { mutableStateOf("") }
    val wirelessOn = remember { EmbeddedShizuku.isWirelessDebuggingOn(context) }
    var running by remember { mutableStateOf(Shizuku.pingBinder()) }

    // Fill the ports in automatically when Wireless debugging advertises them.
    DisposableEffect(supported) {
        var discovery: EmbeddedShizuku.PortDiscovery? = null
        if (supported) {
            try {
                discovery = EmbeddedShizuku.PortDiscovery(
                    context,
                    onPairingPort = { if (it > 0) pairingPort = it.toString() },
                    onConnectPort = { if (it > 0) connectPort = it.toString() },
                ).also { it.start() }
            } catch (e: Throwable) {
                LogUtils.e(TAG, "Port discovery failed", e)
            }
        }
        onDispose { discovery?.stop() }
    }

    // Watch for the service coming up.
    LaunchedEffect(Unit) {
        while (true) {
            running = Shizuku.pingBinder()
            if (running && (handler?.isAuthorized ?: ShizukuPermission.isCantaAuthorized())) {
                onClose(true)
                return@LaunchedEffect
            }
            delay(1000)
        }
    }

    CantaDialog(
        onDismissRequest = { onClose(false) },
        title = stringResource(Res.string.builtin_title),
        scrollable = true,
        buttons = {
            TextButton(onClick = { onClose(false) }) { Text(stringResource(Res.string.close)) }
        },
    ) {
        Text(
            text = stringResource(if (running) Res.string.builtin_running else Res.string.builtin_not_running),
            style = MaterialTheme.typography.titleMedium,
            color = if (running) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
        Spacer(modifier = Modifier.height(8.dp))
        if (!supported) {
            Text(stringResource(Res.string.builtin_needs_android_11), style = MaterialTheme.typography.bodyMedium)
            return@CantaDialog
        }
        Text(stringResource(Res.string.builtin_steps), style = MaterialTheme.typography.bodyMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                val activity = generateSequence(context) { (it as? ContextWrapper)?.baseContext }
                    .filterIsInstance<Activity>().firstOrNull()
                val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                if (needsPermission && activity != null) {
                    activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                    step = Step.NEEDS_NOTIFICATIONS
                } else {
                    try {
                        context.startForegroundService(AdbPairingService.startIntent(context))
                        step = Step.NOTIFICATION_SENT
                    } catch (e: Throwable) {
                        LogUtils.e(TAG, "Could not start the pairing service", e)
                        log = e.toString()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(stringResource(Res.string.builtin_pair_notification)) }
        if (!wirelessOn) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                stringResource(Res.string.builtin_wireless_off),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                try {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    LogUtils.e(TAG, "Failed to open developer options", e)
                }
            },
        ) { Text(stringResource(Res.string.builtin_open_dev_options)) }
        Spacer(modifier = Modifier.height(12.dp))

        val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
        OutlinedTextField(
            value = pairingPort,
            onValueChange = { pairingPort = it.filter(Char::isDigit) },
            label = { Text(stringResource(Res.string.builtin_pairing_port)) },
            keyboardOptions = numeric,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = pairingCode,
            onValueChange = { pairingCode = it.filter(Char::isDigit) },
            label = { Text(stringResource(Res.string.builtin_pairing_code)) },
            keyboardOptions = numeric,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            OutlinedButton(
                enabled = pairingPort.isNotEmpty() && pairingCode.length >= 6,
                onClick = {
                    val port = pairingPort.toIntOrNull() ?: return@OutlinedButton
                    scope.launch {
                        val error = withContext(Dispatchers.IO) {
                            try {
                                if (EmbeddedShizuku.pair(context, port, pairingCode)) null else "pairing rejected"
                            } catch (e: Throwable) {
                                LogUtils.e(TAG, "Pairing failed", e)
                                e.toString()
                            }
                        }
                        log = error ?: ""
                        step = if (error == null) Step.PAIRED else Step.PAIR_FAILED
                    }
                },
            ) { Text(stringResource(Res.string.builtin_pair)) }
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = connectPort,
            onValueChange = { connectPort = it.filter(Char::isDigit) },
            label = { Text(stringResource(Res.string.builtin_connect_port)) },
            keyboardOptions = numeric,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Button(
                enabled = connectPort.isNotEmpty() && step != Step.STARTING,
                onClick = {
                    val port = connectPort.toIntOrNull() ?: return@Button
                    step = Step.STARTING
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            try {
                                EmbeddedShizuku.start(context, port)
                            } catch (e: Throwable) {
                                LogUtils.e(TAG, "Starting failed", e)
                                "ERROR: $e"
                            }
                        }
                        log = result
                        if (result.startsWith("ERROR:")) {
                            step = Step.START_FAILED
                        } else {
                            // Give the server a few seconds to come up and hand over its binder.
                            var waited = 0
                            while (waited < 12000 && !Shizuku.pingBinder()) {
                                delay(500)
                                waited += 500
                            }
                            if (Shizuku.pingBinder()) {
                                step = Step.IDLE
                            } else {
                                step = Step.START_FAILED
                                val serverLog = withContext(Dispatchers.IO) { EmbeddedShizuku.serverLog(context, port) }
                                log = result + "\n\n" + serverLog
                            }
                        }
                    }
                },
            ) { Text(stringResource(Res.string.builtin_start)) }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(
                enabled = connectPort.isNotEmpty(),
                onClick = {
                    val port = connectPort.toIntOrNull() ?: return@TextButton
                    scope.launch {
                        log = withContext(Dispatchers.IO) { EmbeddedShizuku.serverLog(context, port) }
                    }
                },
            ) { Text(stringResource(Res.string.builtin_show_log)) }
        }
        Spacer(modifier = Modifier.height(8.dp))
        val status = when (step) {
            Step.IDLE -> null
            Step.PAIRED -> Res.string.builtin_paired
            Step.PAIR_FAILED -> Res.string.builtin_pair_failed
            Step.STARTING -> Res.string.builtin_starting
            Step.START_FAILED -> Res.string.builtin_start_failed
            Step.NEEDS_NOTIFICATIONS -> Res.string.builtin_need_notification
            Step.NOTIFICATION_SENT -> Res.string.builtin_notification_sent
        }
        if (status != null) {
            Text(stringResource(status), style = MaterialTheme.typography.bodyMedium)
        }
        if (log.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = log.trim(),
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}
