package io.github.samolego.canta.ui.screen

import androidx.compose.runtime.Composable

/** The Shizuku screens use Canta's own theme, so they look like the rest of the app. */
@Composable
fun ShizukuTheme(content: @Composable () -> Unit) {
    content()
}
