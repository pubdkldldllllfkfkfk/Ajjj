# Embedded Shizuku (third-party code)

This module contains source code from:

- Shizuku (server, starter, ADB pairing/starting code), (C) RikkaW and contributors,
  Apache License 2.0 - https://github.com/RikkaApps/Shizuku
- Shizuku-API (aidl, api, provider, shared, server-shared), (C) 2021 RikkaW,
  MIT License - https://github.com/RikkaApps/Shizuku-API

Changes made for Canta: manager application id set to `io.github.samolego.canta`;
the host app is always allowed; the `rish` terminal support was removed.
Binary dependencies: BoringSSL (ndk build by vvb2060), libcxx (LSPosed),
HiddenApiBypass (LSPosed), Bouncy Castle (MIT), Gson (Apache-2.0).
