package rikka.shizuku.embedded

import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.lifecycle.Observer
import moe.shizuku.manager.adb.AdbClient
import moe.shizuku.manager.adb.AdbKey
import moe.shizuku.manager.adb.AdbMdns
import moe.shizuku.manager.adb.AdbPairingClient
import moe.shizuku.manager.adb.PreferenceAdbKeyStore
import java.io.File

/**
 * Starts the embedded Shizuku server from inside the app, over the phone's own
 * Wireless debugging (Android 11+). The server needs shell rights, which only
 * adbd can give, so a one-time pairing with the device's own adbd is required.
 */
object EmbeddedShizuku {

    private const val HOST = "127.0.0.1"

    /** Command that starts the server (run as the shell user). */
    fun starterCommand(context: Context): String {
        val starter = File(context.applicationInfo.nativeLibraryDir, "libshizuku.so")
        return "${starter.absolutePath} --apk=${context.applicationInfo.sourceDir}"
    }

    internal fun adbKey(context: Context): AdbKey {
        val prefs = context.getSharedPreferences("canta_adb_key", Context.MODE_PRIVATE)
        return AdbKey(PreferenceAdbKeyStore(prefs), "canta")
    }

    /** Pairs with the device's adbd using the code from "Pair device with pairing code". Blocking. */
    @RequiresApi(Build.VERSION_CODES.R)
    fun pair(context: Context, port: Int, code: String): Boolean =
        AdbPairingClient(HOST, port, code, adbKey(context)).use { it.start() }

    /** Connects to adbd (already paired) and starts the server. Blocking. Returns the starter's output. */
    @RequiresApi(Build.VERSION_CODES.R)
    fun start(context: Context, port: Int): String {
        val output = StringBuilder()
        AdbClient(HOST, port, adbKey(context)).use { client ->
            client.connect()
            client.shellCommand(starterCommand(context)) { output.append(String(it)) }
        }
        setLastLaunchMode(context, "adb")
        return output.toString()
    }

    /**
     * Explains why the server did not come up: whether its process is alive and everything it logged
     * (its crash, if any), read as the shell user through Wireless debugging. Blocking.
     */
    @RequiresApi(Build.VERSION_CODES.R)
    fun serverLog(context: Context, port: Int, starterOutput: String = ""): String {
        val pid = Regex("pid is (\\d+)").find(starterOutput)?.groupValues?.get(1)
        val command = buildString {
            append("echo '[process]'; ps -A | grep -i shizuku_server; ")
            if (pid != null) {
                append("echo '[log of pid $pid]'; logcat -d --pid=$pid -t 150 2>&1 | tail -n 60; ")
            }
            append("echo '[system log]'; logcat -d -t 1500 | grep -iE 'shizuku|AndroidRuntime|FATAL|canta' | tail -n 30")
        }
        val output = StringBuilder()
        return try {
            AdbClient(HOST, port, adbKey(context)).use { client ->
                client.connect()
                client.shellCommand(command) { output.append(String(it)) }
            }
            output.toString().ifBlank { "(no log lines)" }
        } catch (e: Throwable) {
            "log error: $e"
        }
    }

    /** The result of the last start attempt, kept so it can be read in the app. */
    fun saveLastLog(context: Context, text: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("last_log", text).apply()
    }

    fun lastLog(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("last_log", "") ?: ""

    /** Starts the server with root (`su`), for rooted devices. Blocking. Returns the output. */
    fun startWithRoot(context: Context): String {
        val process = ProcessBuilder("su", "-c", starterCommand(context)).redirectErrorStream(true).start()
        setLastLaunchMode(context, "root")
        process.waitFor(10, java.util.concurrent.TimeUnit.SECONDS)
        val stream = process.inputStream
        val bytes = ByteArray(stream.available().coerceAtLeast(0))
        stream.read(bytes)
        return String(bytes)
    }

    private const val PREFS = "built_in_shizuku"
    private const val KEY_START_ON_BOOT = "start_on_boot"
    private const val KEY_LAST_MODE = "last_launch_mode"

    /** "Start on boot" setting (shared with the app's settings screen). */
    fun isStartOnBootEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_START_ON_BOOT, false)

    fun setStartOnBoot(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_START_ON_BOOT, enabled).apply()
    }

    /** How the server was started last time: "root" or "adb". */
    fun lastLaunchMode(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_MODE, "adb") ?: "adb"

    internal fun setLastLaunchMode(context: Context, mode: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LAST_MODE, mode).apply()
    }

    /** Whether the app may switch Wireless debugging on by itself (needed to start on boot without root). */
    fun hasSecureSettingsPermission(context: Context): Boolean =
        context.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Whether Wireless debugging is switched on in Developer options. */
    fun isWirelessDebuggingOn(context: Context): Boolean =
        try {
            android.provider.Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) == 1
        } catch (e: Exception) {
            false
        }

    /** Finds the pairing and connect ports advertised by Wireless debugging. */
    @RequiresApi(Build.VERSION_CODES.R)
    class PortDiscovery(
        context: Context,
        onPairingPort: (Int) -> Unit,
        onConnectPort: (Int) -> Unit,
    ) {
        private val pairing = AdbMdns(context, AdbMdns.TLS_PAIRING, Observer { onPairingPort(it) })
        private val connect = AdbMdns(context, AdbMdns.TLS_CONNECT, Observer { onConnectPort(it) })

        fun start() {
            pairing.start()
            connect.start()
        }

        fun stop() {
            pairing.stop()
            connect.stop()
        }
    }
}
