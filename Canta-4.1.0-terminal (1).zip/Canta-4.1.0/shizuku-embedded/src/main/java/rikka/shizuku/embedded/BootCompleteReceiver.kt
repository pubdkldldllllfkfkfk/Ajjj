package rikka.shizuku.embedded

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.Observer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import moe.shizuku.manager.adb.AdbMdns
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Starts the embedded Shizuku after boot, like the Shizuku app: with root, or (Android 13+)
 * with Wireless debugging when the app was granted WRITE_SECURE_SETTINGS.
 * Adapted from Shizuku (Apache-2.0), (C) RikkaW.
 */
class BootCompleteReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!EmbeddedShizuku.isStartOnBootEnabled(context) || Shizuku.pingBinder()) return

        val mode = EmbeddedShizuku.lastLaunchMode(context)
        if (mode == "root") {
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    EmbeddedShizuku.startWithRoot(context)
                } catch (_: Throwable) {
                }
                pending.finish()
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            EmbeddedShizuku.hasSecureSettingsPermission(context)
        ) {
            adbStart(context)
        }
    }

    private fun adbStart(context: Context) {
        val resolver = context.contentResolver
        Settings.Global.putInt(resolver, "adb_wifi_enabled", 1)
        Settings.Global.putInt(resolver, Settings.Global.ADB_ENABLED, 1)
        Settings.Global.putLong(resolver, "adb_allowed_connection_time", 0L)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            val latch = CountDownLatch(1)
            val mdns = AdbMdns(context, AdbMdns.TLS_CONNECT, Observer<Int> { port ->
                if (port <= 0) return@Observer
                try {
                    EmbeddedShizuku.start(context, port)
                } catch (_: Throwable) {
                }
                latch.countDown()
            })
            mdns.start()
            latch.await(5, TimeUnit.SECONDS)
            mdns.stop()
            pending.finish()
        }
    }
}
