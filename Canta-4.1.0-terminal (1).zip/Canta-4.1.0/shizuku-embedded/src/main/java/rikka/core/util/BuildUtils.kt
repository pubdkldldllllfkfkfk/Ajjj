package rikka.core.util

import android.os.Build

/** Minimal stand-in for rikkax-core's BuildUtils (only what the ADB client uses). */
object BuildUtils {
    val atLeast29: Boolean get() = Build.VERSION.SDK_INT >= 29
    val atLeast30: Boolean get() = Build.VERSION.SDK_INT >= 30
}
