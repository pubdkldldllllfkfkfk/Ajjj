package moe.shizuku.manager.adb

import android.annotation.TargetApi
import android.app.ForegroundServiceStartNotAllowedException
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.lifecycle.Observer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import rikka.core.ktx.unsafeLazy
import rikka.shizuku.embedded.R
import rikka.shizuku.Shizuku
import rikka.shizuku.embedded.EmbeddedShizuku
import java.net.ConnectException
import java.util.concurrent.atomic.AtomicInteger

/**
 * Pairing through a notification, like the Shizuku app: it finds the pairing
 * service, shows a notification with a text field for the 6-digit code, pairs,
 * and then starts the server by itself.
 * Adapted from Shizuku (Apache-2.0), (C) RikkaW.
 */
@TargetApi(Build.VERSION_CODES.R)
class AdbPairingService : Service() {

    companion object {
        const val notificationChannel = "adb_pairing"
        private const val tag = "AdbPairingService"
        private const val notificationId = 1
        private const val replyRequestId = 1
        private const val stopRequestId = 2
        private const val startAction = "start"
        private const val stopAction = "stop"
        private const val replyAction = "reply"
        private const val remoteInputResultKey = "paring_code"
        private const val portKey = "paring_code"
        private const val accent = 0xFF2EEA4A.toInt()
        private const val smallIcon = android.R.drawable.stat_notify_sync

        fun startIntent(context: Context): Intent =
            Intent(context, AdbPairingService::class.java).setAction(startAction)

        private fun stopIntent(context: Context): Intent =
            Intent(context, AdbPairingService::class.java).setAction(stopAction)

        private fun replyIntent(context: Context, port: Int): Intent =
            Intent(context, AdbPairingService::class.java).setAction(replyAction).putExtra(portKey, port)
    }

    private var adbMdns: AdbMdns? = null

    private val observer = Observer<Int> { port ->
        Log.i(tag, "Pairing service port: $port")
        if (port <= 0) return@Observer
        // The service could be killed before the user finishes typing, so the port travels in the Intent.
        getSystemService(NotificationManager::class.java).notify(notificationId, createInputNotification(port))
    }

    private var started = false

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(
                notificationChannel,
                getString(R.string.shz_channel),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setSound(null, null)
                setShowBadge(false)
                setAllowBubbles(false)
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = when (intent?.action) {
            startAction -> onStart()
            replyAction -> {
                val code = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(remoteInputResultKey) ?: ""
                val port = intent.getIntExtra(portKey, -1)
                if (port != -1) onInput(code.toString(), port) else onStart()
            }
            stopAction -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                null
            }
            else -> return START_NOT_STICKY
        }
        if (notification != null) {
            try {
                startForeground(notificationId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST)
            } catch (e: Throwable) {
                Log.e(tag, "startForeground failed", e)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && e is ForegroundServiceStartNotAllowedException) {
                    getSystemService(NotificationManager::class.java).notify(notificationId, notification)
                }
            }
        }
        return START_REDELIVER_INTENT
    }

    private fun startSearch() {
        if (started) return
        started = true
        adbMdns = AdbMdns(this, AdbMdns.TLS_PAIRING, observer).apply { start() }
    }

    private fun stopSearch() {
        if (!started) return
        started = false
        adbMdns?.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopSearch()
    }

    private fun onStart(): Notification {
        startSearch()
        return searchingNotification
    }

    private fun onInput(code: String, port: Int): Notification {
        GlobalScope.launch(Dispatchers.IO) {
            val key = try {
                AdbKey(PreferenceAdbKeyStore(getSharedPreferences("canta_adb_key", Context.MODE_PRIVATE)), "canta")
            } catch (e: Throwable) {
                handleResult(false, e)
                return@launch
            }
            AdbPairingClient("127.0.0.1", port, code, key).runCatching {
                start()
            }.onFailure {
                handleResult(false, it)
            }.onSuccess {
                handleResult(it, null)
            }
        }
        return workingNotification
    }

    private fun handleResult(success: Boolean, exception: Throwable?) {
        if (success) {
            Log.i(tag, "Pair succeed")
            stopSearch()
            notifyText(getString(R.string.shz_pair_ok_title), getString(R.string.shz_pair_ok_text), keepForeground = true)
            startServerAfterPairing()
            return
        }

        val text = when (exception) {
            is ConnectException -> getString(R.string.shz_cannot_connect)
            is AdbInvalidPairingCodeException -> getString(R.string.shz_wrong_code)
            is AdbKeyException -> getString(R.string.shz_key_error)
            else -> exception?.let { Log.getStackTraceString(it) }
        }
        Log.w(tag, "Pair failed", exception)
        notifyText(getString(R.string.shz_pair_fail_title), text)
        stopSelf()
    }

    /** After pairing: find the connect port of Wireless debugging and start the server. */
    private fun startServerAfterPairing() {
        GlobalScope.launch(Dispatchers.IO) {
            val connectPort = AtomicInteger(-1)
            val mdns = AdbMdns(this@AdbPairingService, AdbMdns.TLS_CONNECT, Observer { p -> if (p > 0) connectPort.set(p) })
            mdns.start()
            var waited = 0
            while (waited < 15000 && connectPort.get() <= 0) {
                delay(500)
                waited += 500
            }
            mdns.stop()

            val port = connectPort.get()
            if (port <= 0) {
                notifyText(getString(R.string.shz_start_fail_title), "No connect port found. Is Wireless debugging on?")
                stopSelf()
                return@launch
            }
            val output = try {
                EmbeddedShizuku.start(this@AdbPairingService, port)
            } catch (e: Throwable) {
                Log.e(tag, "Start failed", e)
                "ERROR: $e"
            }
            waited = 0
            while (waited < 12000 && !Shizuku.pingBinder()) {
                delay(500)
                waited += 500
            }
            if (Shizuku.pingBinder()) {
                notifyText(getString(R.string.shz_started_title), getString(R.string.shz_started_text))
            } else {
                val serverLog = EmbeddedShizuku.serverLog(this@AdbPairingService, port)
                notifyText(
                    getString(R.string.shz_start_fail_title),
                    (output.trim().ifEmpty { "No output" }) + "\n\n" + serverLog
                )
            }
            stopSelf()
        }
    }

    private fun notifyText(title: String, text: String?, keepForeground: Boolean = false) {
        if (!keepForeground) stopForeground(STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java).notify(
            notificationId,
            Notification.Builder(this, notificationChannel)
                .setColor(accent)
                .setSmallIcon(smallIcon)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .build()
        )
    }

    private val stopNotificationAction by unsafeLazy {
        val pendingIntent = PendingIntent.getService(
            this, stopRequestId, stopIntent(this),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0
        )
        Notification.Action.Builder(null, getString(R.string.shz_stop_searching), pendingIntent).build()
    }

    private val replyNotificationAction by unsafeLazy {
        val remoteInput = RemoteInput.Builder(remoteInputResultKey).run {
            setLabel(getString(R.string.shz_code_label))
            build()
        }
        val pendingIntent = PendingIntent.getForegroundService(
            this, replyRequestId, replyIntent(this, -1),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            else PendingIntent.FLAG_UPDATE_CURRENT
        )
        Notification.Action.Builder(null, getString(R.string.shz_input_code), pendingIntent)
            .addRemoteInput(remoteInput)
            .build()
    }

    private fun replyNotificationAction(port: Int): Notification.Action {
        // Ensure the pending intent is created, then refresh it with the discovered port.
        val action = replyNotificationAction
        PendingIntent.getForegroundService(
            this, replyRequestId, replyIntent(this, port),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            else PendingIntent.FLAG_UPDATE_CURRENT
        )
        return action
    }

    private val searchingNotification by unsafeLazy {
        Notification.Builder(this, notificationChannel)
            .setColor(accent)
            .setSmallIcon(smallIcon)
            .setContentTitle(getString(R.string.shz_searching))
            .addAction(stopNotificationAction)
            .build()
    }

    private fun createInputNotification(port: Int): Notification =
        Notification.Builder(this, notificationChannel)
            .setColor(accent)
            .setContentTitle(getString(R.string.shz_found))
            .setSmallIcon(smallIcon)
            .addAction(replyNotificationAction(port))
            .build()

    private val workingNotification by unsafeLazy {
        Notification.Builder(this, notificationChannel)
            .setColor(accent)
            .setContentTitle(getString(R.string.shz_working))
            .setSmallIcon(smallIcon)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
